#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <dirent.h>
#include <string.h>
#include <pthread.h>
#include "ssu_runtime.h"

#define MAX_SIZE 1024
#define TIME_LIMIT 5
#define WARNING_SCORE -0.1
#define ERROR_SCORE 0

//total question number
struct ans_num {
	char name[MAX_SIZE];
	char file_name[MAX_SIZE];
	int name_i;
	int name_s; // ==0 -> .c, !=0 -> .txt
	int num;
	double score;
};

double finalScore[100][100] = { 0 };
double sum[100] = { 0 };

int compare(const void*a, const void*b) {
	return strcmp(*(char**)a, *(char**)b);
}


void *threadRoutine(void *argumentPointer);

void gradingC(char*problemC, char*path_a);
static int check_thread_status(char *pnWorkStatus, int nWaitTime);
int list_dir(const char* path,char**saveName);
void ans_numSort(struct ans_num* num, int);
void subdirOutput(char *wd, char* studentId, char*wd_a, char*answerQ);
void programCompile(char*answerQ,char*path,int ch ,char*stdId);
//....
char* studentFile[MAX_SIZE];
void EraseSpace(char *ap_string);

int innerFileCount;
int e_flag = 0;//e옵션시 1로바뀜
int p_flag = 0;//p옵션시 1로바뀜
int t_flag = 0;//t옵션시 1로바뀜
int c_flag = 0;//c옵션시 1로바뀜
void optionE(char*);
void optionP();
void optionH();
void optionC(int count);
char cName[5][MAX_SIZE];//c옵션시 추가로 받는 파라미터
char eName[MAX_SIZE];//e옵션시 추가로 받는 파라미터
char tName[5][MAX_SIZE];//t옵션시 추가로 받는 파라미터
int optCount1 = 0;//c옵션 파라미터의 개수
int optCount2 = 0;//t옵션 파라미터의 개수

void makeScore_table(char*, struct ans_num*, int);
void makeFinal_Score_table(char**stdId, struct ans_num* num, char* folder, int stdCount, int ansCount);


//______-----_____--------------------
//total exception!!!
//.exe .stdout .csv not count!!!!!!
//-------------------------------------
int main(int argc, char **argv)
{
	//-----
	struct timeval begin_t, end_t;
	gettimeofday(&begin_t, NULL);
	//---time

	//<---
	char* studentId[MAX_SIZE];
	char* answerQ[MAX_SIZE];

	//인자 개수에 대한 예외처리
	if(argc==1){
		fprintf(stderr, "Usage : ssu_score <STUDENTDIR> <TRUEDIR> [OPTION]\n");
		exit(1);
	}

	//-h옵션이 학생,정답 디렉토리와 같이 오지 않을 때
	if (!strcmp(argv[1], "-h")) {
		optionH();
		gettimeofday(&end_t, NULL);
		ssu_runtime(&begin_t, &end_t);
		exit(0);
	}
/*
	//-c옵션이 학생, 정답 디렉토리와 같이 오지 않을 때
	if (!strcmp(argv[1], "-c")) {

		//-c옵션이 단독으로 있을 때

		//STUDENT ANSWER 폴더가 인자에 포함되지 않는 경우
		//.csv파일의 유무 판단
		//없으면 에러

		//있으면
		int cOptCheck=0;
		int cSum[5];
		while(cOptCheck<optCount1){

			int cComplete = 1;
			//제일 첫번째줄을 버릴거야.
			//->첫번째 줄을 그냥 읽어 더미변수에
			//두번째줄부터는 한줄씩 읽어
			while(fgets로 더이상 못읽으면 나온다){
				//아직 csv파일을 읽는거야

				//,앞을 토큰분리시킬거야
				//cName[cOptCheck]이랑 비교해서 같은 학번이 있으면 계속 토큰분리
				//같은학번이 아니면 
				continue;
				while(토큰분리조건){
					//,가 더이상 나오지 않을때까지 하고  
				}
				//제일 마지막 sum부분은 cSum에 따로 받아서 정리하자
				//완료되었음을 나타내고(변수cComplete = 0로 체크), break!		

			}
			// 만약 같은 학번이 없다면?
			if(cComplete){
				printf("사람이 없어서 출력못함\n");
			}				
			cOptCheck++;
		}


	}
*/
	//옵션 확인
	char std_folder[MAX_SIZE];
	char ans_folder[MAX_SIZE];
	
	strcpy(std_folder,argv[1]);
	strcpy(ans_folder,argv[2]);
	
int array_count=0;	
	
while(array_count<argc){

	//'-'인식 (Q. 파일 이름 사이에 '-'가 있으면??) ->옵션인지 인자인지 구분

	if(argv[array_count][0] == '-'){

		//옵션이면 어떤 옵션인지 파악해서 함수에 넣든 결과를 출력하든...
		switch(argv[array_count][1]){
			case 'h':
				//사용법 출력하고 종료
				optionH();
				gettimeofday(&end_t, NULL);
				ssu_runtime(&begin_t, &end_t);
				exit(0);
			case 'p':
				array_count++;
				p_flag = 1;
				optionP();
				// -p : optionP함수로 들어감. => 점수파일 읽어오기, 읽어온 것들로 sum배열 채워서 평균출력
				break;
			case 'e':
				//인자가 오나 안오나 체크
				// 인자가 오면?  다음에 오는게 -가 있는지 없는지 확인  
				if((array_count+1)!=argc){

					// -가 없으면?
					// flag_e를 1로 만들기
					// 뒤에 오는 인자 하나만 e배열에 넣어서 저장
					if(argv[array_count+1][0]!='-'){
						e_flag=1;
						strcpy(eName,argv[array_count+1]);
						array_count++;
					}
					// -가 있으면?
					else{
						printf("Usage : -e <DIRNAME>\n");
						exit(1);
					}
					//-e 옵션이 없으니 error

				}
				else{
					// 안오면?	
					printf("Usage : -e <DIRNAME>\n");
					exit(1); 
					// error
				}
				break;
			case't':
				//810번째 줄에 구현해놓음
				printf("t옵션이 감지되었습니다!\n");
				if((array_count+1)!=argc){
					//인자가 오면?
					//다음인자가 -가 있는지 없는지
					//-가 있다면?	
					printf("인자가 오면? 판단하는 부분\n");
					if(argv[array_count+1][0]=='-'){
						array_count++;
						printf("Usage : -t <QNAME1> <QNAME2> ... <QNAME5>\n");
						break;
					}
					//없다면
					else{	
						printf("정상적인 인자가 왔음!\n");
						t_flag=1;	
						//t배열에 저장	
						while(optCount2<5){
							array_count++;
							strcpy(tName[optCount2],argv[array_count]);
							printf("%s, %s\n", tName[optCount2], argv[array_count]);
							optCount2++;
							if(array_count+1 >= argc) {
								printf("이제 이 거 나가자\n");
								break;
							}

						}
					}
				}
				else{
					// 안오면?
					printf("-t's variable argument is not detected!");
					printf("Usage : -t <QNAME1> <QNAME2> ... <QNAME5>\n");
					array_count++;
					break; 
					// error
				}
				break;
			case'c':
				//인자가 오면
				if((array_count+1)!=argc){

					//-가 있는지 없는지
					//-가 있으면?
					if(argv[array_count+1][0]=='-'){
						array_count++;
						printf("Usage : -c <ID1> <ID2> ... <ID5>\n");
						break;
					}
					//-가 없으면
					else{
						c_flag=1;
						//c배열에 저장
						while(optCount1<5){

							strcmp(tName[optCount2],argv[array_count]);
							optCount1++;
							array_count++;
							if(argv[array_count+1][0]=='-'){
								break;
							}
						}

					}
				}
				else{
					array_count++;
					printf("Usage : -c <ID1> <ID2> ... <ID5>\n");
					break;

				}
				break;
			default:
				printf("Unknown option %c\n", optopt);
				exit(1);
		}
	}
	else//옵션이 아니면 넘긴다
		array_count++;

}


	//student
	DIR *dir = opendir(std_folder);
	if (dir == NULL) {
		printf("first directory failed open\n");
		exit(1);
	}

	struct dirent *de = NULL;
	struct dirent *subde = NULL;
	int i, j;
	int num_s = 0;
	int num_a = 0;

	//STD_DIR folder name save
	while ((de = readdir(dir)) != NULL) {

		//save
		if (num_s >= 100) {
			printf("can not save\n");
		}
		if ((!strcmp(de->d_name, ".")) || (!strcmp(de->d_name, "..")))
			continue;

		studentId[num_s] = de->d_name;
		num_s++;
	}
	//STD_DIR folder name sort	
	qsort(studentId, num_s, sizeof(studentId[0]), compare);
//
	//--------------------------------------------------------------------



	// ANS_DIR folder;
	DIR *dir2 = opendir(ans_folder);
	if (dir2 == NULL) {
		printf("failed open for answer file\n");
		exit(1);
	}
	struct dirent *de2 = NULL;

	struct dirent **namelist;
	char * pathName;
	char srcName[PATH_MAX];
	char tarName[PATH_MAX];
	int listcount;

	char path[MAX_SIZE];

	int problemC = 0;
	char *proNum[MAX_SIZE];

	if ((listcount = scandir(ans_folder, &namelist, NULL, alphasort)) == -1)
	{
		fprintf(stderr, "%s Directory Scan Err\n", ans_folder);
		exit(1);
	}



	for (i = 2; i < listcount; i++)
	{
		if (strstr(namelist[i]->d_name, ".csv") != NULL) {
			listcount--;
			continue;
		}
		//pathName = namelist[i]->d_name;
		answerQ[i - 2] = namelist[i]->d_name;
	}

	//answer to struct ans_num
	struct ans_num* num;
	num = (struct ans_num*)malloc(sizeof(struct ans_num)* MAX_SIZE);

	char* text_f;
	int dcheck = 0;
	for (i = 0; i < listcount - 2; i++) {
		strcpy(num[i].name, answerQ[i]);
		num[i].num = i;
		char* text_l = (char*)malloc(1000);
		strcpy(text_l, answerQ[i]);
		text_f = strtok(text_l, "-");
		while (text_f != NULL) {
			dcheck = 1;
			num[i].name_s = atoi(text_f);
			text_f = strtok(NULL, " ");
		}
		if (!strstr(num[i].name, "-")) {
			num[i].name_s = 0;
		}
		num[i].name_i = atoi(answerQ[i]);
//----------------------//		
free(text_l);
//----------------------//

	}
	//AND_DIR folder name sort
	ans_numSort(num, listcount - 2);

	for (i = 0; i < listcount - 2; i++) {
		strcpy(answerQ[i], num[i].name);
	}

	//파일 이름에 확장자명 추가
	for (i = 0; i < listcount - 2; i++) {
		if (num[i].name_s != 0) {
			sprintf(num[i].file_name, "%s.txt", num[i].name);
		}
		else {
			sprintf(num[i].file_name, "%s.c", num[i].name);
		}
	}


	//-------------- ans folder sort!

	//ansNum에 문제들 저장 -> csv파일 생성
	makeScore_table(ans_folder, num, listcount);

//	printf("score table end!\n");
	//-----------------------------------------

	getcwd(path, 200);
	//현재 위치 확인


	char* proNum_txt[MAX_SIZE];
	int problemT=0;
	char nPath[PATH_MAX];
	strcpy(nPath,path);
	for(i=2;i<listcount;i++){
		char* problemNum=namelist[i]->d_name;

		sprintf(nPath,"%s/%s/%s",path,ans_folder,namelist[i]->d_name);
		if(strchr(answerQ[i-2],'-')==NULL){

			//c file
			proNum[problemC]=namelist[i]->d_name;
			problemC++;
			programCompile(nPath,problemNum,0,NULL);////

		}
		else{
			//txt file
			proNum_txt[problemT]=namelist[i]->d_name;
			problemT++;
			//textfile compare function

		}

		printf("%s\n",nPath);
}


//---------------------------------------------------------------------

struct stat file_info;
getcwd(path,200);
struct dirent **nlist;
char*saveName[PATH_MAX];
int k;
char path1[MAX_SIZE];
int new_listcount;


//e option이 1일 때... 폴더생성
if(e_flag){	
		//어디에? DIRNAME/학번/문제번호_error.txt
		//만약 DIRNAME이 존재하면 삭제후 다시 생성
		char dirPathName[MAX_SIZE];
		sprintf(dirPathName,"%s/%s",path,eName);
		//..../DIRNAME

		if(mkdir(dirPathName,0777)<0){//에러 -> 이미 존재함일 수도 있고 다른 에러일 수도 있다.
			//먼저 삭제해보자.
//			printf("파일이 존재하는지 확인해보자!\n");
			char deleteDirname[MAX_SIZE];
			sprintf(deleteDirname,"rm -rf %s",dirPathName);
//			printf("deleteDirname : %s\n", deleteDirname);
			system(deleteDirname);
			//삭제했으니 다시생성
			if(mkdir(dirPathName,0777)<0){
				//파일의 존재때문에 발생한 에러가 아님.
				fprintf(stderr, "mkdir error");
				exit(1);
			}		
		}

		//DIRNAME 폴더가 생성됐다.

		// DIRNAME 밑에 학번 폴더 생성	
		//studentId에 학번이 저장되어 있음. 개수는 num_s
		char studentPathName[MAX_SIZE];
		int p;
		for(p=0;p<num_s;p++){
			sprintf(studentPathName,"%s/%s", eName,studentId[p]);
//			printf("DIRNAME 밑에 학번 폴더를 생성합니다!\n");
			if(mkdir(studentPathName,0777)<0){
				fprintf(stderr, "mkdir error for %s",studentPathName);
				exit(1);
			}
		}
		//학번들 폴더 생성완료

}







for(j=0;j<num_s;j++){
	sprintf(path1,"%s/%s/%s",path,std_folder,studentId[j]);
	int ffd;

	new_listcount = list_dir(path1,saveName);
	//printf("new_iistcount = %d\n", new_listcount);
	///////////////////////////////////////////////////////////////////
	struct ans_num*num_sf;
	num_sf = (struct ans_num*)malloc(sizeof(struct ans_num)* new_listcount);

	char* text_f2;

	for (i = 0; i < new_listcount; i++) {
		strcpy(num_sf[i].name , saveName[i]);
		num_sf[i].num = i;
		char* test_l2 = (char*)malloc(1000);
		strcpy(test_l2, saveName[i]);
		text_f2 = strtok(test_l2, ".-");
		while (text_f2 != NULL) {
			text_f2 = strtok(NULL, ".");

			num_sf[i].name_s = atoi(text_f2);
			if (strcmp(text_f2, "txt") == 0) {
				break;
			}
			else if (strcmp(text_f2, "c") == 0) {
				num_sf[i].name_s = 0;
				break;
			}
			else
				break;
			//num_sf[i].name_s = atoi(text_f2);
		}
		num_sf[i].name_i = atoi(saveName[i]);
	}

	ans_numSort(num_sf, new_listcount);

	for (i = 0; i < new_listcount; i++) {
		saveName[i] = num_sf[i].name;
	}
	///////////////////////////////////////////////
//	char newpath[PATH_MAX];
	int newfd;
	for(i=0;i<new_listcount;i++){

//		sprintf(newpath,"%s/%s",path1,saveName[i]);
//....??왜???
		if(strchr(saveName[i],'-')==NULL){
			if(strstr(saveName[i],".c")!=NULL){
				char pronum[MAX_SIZE];
				strcpy(pronum,strtok(saveName[i],"."));
				//c file

printf("%s\n",path1);
				programCompile(path1,pronum,1,studentId[j]);
//				printf("programCompile 완료!\n");
				//saveName = 11 ,12,13,14

			}
		}	
		else{

			//txt file
			//textfile compare function
//--------------------------------------------------------//


		}

	}

	//-----------------------------------------------------------------------
}


//-------------------directory search end!!!!



//-------------------directory search end!!!!

//텍스트 비교
//----txt file
//problemT -> txt파일의 개수
//	45	
//proNum_txt -> txt파일의 문제 이름 저장
//	1-1 ~ 10-5

FILE *noSpace_ans_txt;
FILE *noSpace_std_txt;
FILE *ans_txt;
FILE *std_txt;
char txt_path_ans[10000];
char txt_path_std[10000];

int s1,s2;
for (i = 0; i < problemT; i++) {
	//answer path name -> answerFile open
	//1 answer file -> all student file grade!! for(  for() );

	printf("첫 구간 진입!\n");	

	sprintf(txt_path_ans,"%s/%s/%s/%s.txt",path,ans_folder,proNum_txt[i],proNum_txt[i]);
	//sprintf(txt_no_path_a,"%s/%s/%s/no_spa_%s.txt",path,ans_folder,proNum_txt[i],proNum_txt[i]);

	ans_txt=fopen(txt_path_ans,"r");
	char std_txt_context[3000]="";
	char ans_txt_context[MAX_SIZE]="";
	char *answer_context=NULL;
	char *stud_context=NULL;
	answer_context=fgets(ans_txt_context,sizeof(ans_txt_context),ans_txt);

	for(j=0;j<num_s;j++){
		sprintf(txt_path_std,"%s/%s/%s/%s.txt",path,std_folder,studentId[j],proNum_txt[i]);
		std_txt=fopen(txt_path_std,"r");
		int fd_std_txtFile=0;
		int fd_std_txtFile_size=0;
		fd_std_txtFile=open(txt_path_std,O_RDWR,0777);
		fd_std_txtFile_size=lseek(fd_std_txtFile,0,SEEK_END);
		printf("%s 파일크기는 %d입니다.\n", txt_path_std, fd_std_txtFile_size);
		if(fd_std_txtFile_size<=1) {
			close(fd_std_txtFile);
			continue;
		}
		close(fd_std_txtFile);	
		printf("여기야...???\n");
		printf("%s\n",txt_path_std);
		if(std_txt==NULL)
			continue;

		int tokenNumber=0;
		printf("...?\n");
		stud_context=fgets(std_txt_context,sizeof(std_txt_context),std_txt);
		printf("token start!\n");
		//토큰분리
		printf("answer_context:%s\n",answer_context);
		printf("stud_context:%s\n",stud_context);
		if(stud_context==NULL)
			continue;
		char* txt_f=(char*)malloc(1000);
		char* txt_l=(char*)malloc(1000);
		strcpy(txt_l,answer_context);

		printf("txt_l : %s?\n",txt_l);
		char txt_s_1[100];
		strcpy(txt_s_1,stud_context);
		//copy

		char buf_std[100][100];
		char buf[100][100];

		int tokenNumber_std=0;
		printf("std token start!\n");
		strcpy(txt_s_1,strtok(txt_s_1," \n"));
		strcpy(buf_std[tokenNumber_std],txt_s_1);
		printf("txt_s_1: %s\n",txt_s_1);
		while(txt_s_1 !=NULL){
			char *txt_s_1_1 = NULL;
			txt_s_1_1 = strtok(NULL," \n");
			if(txt_s_1_1==NULL) break;
			tokenNumber_std++;
			strcpy(buf_std[tokenNumber_std],txt_s_1_1);
			printf("txt_s_1 : %s\n",txt_s_1_1);
		}
		int kkkk;
		for(kkkk=0;kkkk<=tokenNumber_std;kkkk++){
			printf("%d : %s\n",kkkk,buf_std[kkkk]);
		}

		printf("tokenNumber_Std : %d\n", tokenNumber_std++);

		printf("\n\ntoken_std end!\n\n");


		printf("\n\n\n\n std end! \n\n");


		while(1){
			tokenNumber=0;
			printf("\n\n txt_l : %s\n",txt_l);
			char text_second[MAX_SIZE];
			txt_f=strtok(txt_l,":");
			printf("txt_l:%s\n",txt_l);

			//답안에 :가 없을 경우
			if(txt_l==NULL){
				printf("---txt_f%s\n",txt_f);
				strcpy(text_second,txt_f);
				printf("txt_second : %s\n",text_second);
				printf("txt_f start! : %s\n", txt_f);
			}
			else{
				printf("----\n");
				strcpy(txt_l, txt_f);
			}
			char txt_f_2[100];
			strcpy(txt_f_2, strtok(txt_f, " \n"));
			if(txt_f==NULL){
				strcpy(buf[tokenNumber], txt_f_2);
				strcpy(txt_f,txt_f_2);
			}
			else{
				strcpy(buf[tokenNumber], txt_f);

				printf("txt_f first : %s\n", txt_f);
			}
			while(txt_f != NULL){
				txt_f = strtok(NULL," \n");
				if(txt_f == NULL) break;
				//if cans't use -> strcpy error
				tokenNumber++;
				strcpy(buf[tokenNumber],txt_f);
				printf("txt_f : %s\n",txt_f);
			}

			//정답 토큰분리
			int llll;
			for(llll=0;llll<=tokenNumber;llll++){
				printf("%d : %s\n",llll,buf[llll]);
			}



			printf("token number : %d\n",tokenNumber++);

			printf("\n\ntoken end\n\n");

			//token compare
			//
			int token_check=0;
			printf("%d == %d...?\n",tokenNumber_std, tokenNumber);
			if(tokenNumber_std == tokenNumber){
				int tok;
				for(tok=0;tok<tokenNumber_std;tok++){

					printf("buf_std:%s buf:%s\n", buf_std[tok],buf[tok]);
					token_check=3;
					if(!strcmp(buf_std[tok],buf[tok])){

						printf("====same====\n\n");
						token_check=1;
						printf("buf_std에 있는 말이 뭔데? :%s\n\n",buf_std[tok]);
						continue;
					}
					printf("token_check?:%d\n",token_check);
					if(token_check==3){
						break;
					}

				}

				if(token_check==1){
					printf("correct!!\n");
					int t_ccount;
					int t_ind_num=0;
					for(t_ccount=0;t_ccount<listcount-2;t_ccount++){
						if(!strcmp(answerQ[t_ccount],proNum_txt[i])){
							t_ind_num=t_ccount;
							printf("%d\n",t_ind_num);
							break;
						}
					}
					int ss_id=atoi(studentId[j])-20190001;
					finalScore[ss_id][t_ind_num]=num[t_ccount].score;
					printf("점수저장!!\n");

				}
				else{
					txt_l=strtok(text_second,":");
					if(txt_l==NULL){
						printf("not same\n");
						break;
					}
					else{
						tokenNumber=0;
						printf("txt_l : %s\n",txt_l);
						


					}
				}
			}
				else{

				break;
				}
				break;
		}
		printf("....여기는 어디니..??\n");

		//	 fclose함수는 종료시 오류가 발생하면
		//	   0이 아닌 다른값을 리턴하므로 비정상 종료로 판단되면
		//	   안내후 프로그램을 종료
		s2 = fclose(std_txt);
		if (s2 != 0) {
			printf("stream close error\n");

		}
//-------------------
free(txt_f);
free(txt_l);
//----------------------

	}
	printf("...here..?\n");

	s1 = fclose(ans_txt);
	if (s1 != 0) {
		printf("stream close error\n");

	}

	printf("....여기까지는 오니...??\n");
	//	remove(no_path_a);


}





//answer!
// proNum[] c file name
//problemC; -> c file count

//student
//num_s -> student number count
//studentId[] studentId name



//printf("problem..?\n");
FILE *answerFile;
FILE *noSpaceAnsFile;
FILE *stdFile;
FILE *noSpaceStdFile;
char path_ans[MAX_SIZE];
char no_path_a[MAX_SIZE];


printf("학생들 답안 채점을 시작합니다!\n\n");

for (i = 0; i < problemC; i++) {
	//answer path name -> answerFile open
	//1 answer file -> all student file grade!! for(  for() );

	sprintf(path_ans,"%s/%s/%s",path,ans_folder,proNum[i]);
	sprintf(no_path_a,"%s/%s/%s/no_spa_%s.txt",path,ans_folder,proNum[i],proNum[i]);

	// 정답의 공백을 제거
	gradingC(proNum[i], path_ans);


	for (j = 0; j < num_s; j++) {
		char path_std[MAX_SIZE]; // student path name -> studentFile open
		char no_path_s[MAX_SIZE];
	
		noSpaceAnsFile = fopen(no_path_a, "r");

		sprintf(path_std, "%s/%s/%s", path,std_folder,studentId[j]);
		sprintf(no_path_s, "%s/%s/%s/no_spa_%s.txt", path,std_folder,studentId[j],proNum[i]);
				
		printf("학생답안 원본있는 경로 %s\n",path_std);
		printf("학생답안 공백제거 경로 %s\n",no_path_s);
 
		// 학생의 공백을 제거
		gradingC(proNum[i], path_std);
		noSpaceStdFile = fopen(no_path_s, "r");

		// 파일의 크기가 0이면 continue
		int fd_stdFile_size=0;
		int fd_ansFile_size=0;
		int fd_stdFile,fd_ansFile;
		fd_stdFile=open(no_path_a,O_RDWR,0777);
		fd_ansFile=open(no_path_s,O_RDWR,0777);
		fd_stdFile_size=lseek(fd_stdFile,0,SEEK_END);
		fd_ansFile_size=lseek(fd_ansFile,0,SEEK_END);
		
		printf("파일크기:학생은 %d,정답은 %d\n",fd_stdFile_size,fd_ansFile_size);	

		if (fd_stdFile_size==0||fd_ansFile_size==0)
			continue;
		
		close(fd_stdFile);
		close(fd_ansFile);
				
		int state1, state2;

		// 두개의 파일에 저장된 데이터를 비교함
		while (1) {
				char strTemp[MAX_SIZE] = "";
				char ansTemp[MAX_SIZE] = "";
				char *pAnswerLine = NULL;
				char *pStdLine = NULL;

				pAnswerLine = fgets(ansTemp, sizeof(ansTemp), noSpaceAnsFile);
				pStdLine = fgets(strTemp, sizeof(strTemp), noSpaceStdFile);
		
				// 확인
				printf("ansTemp : %s", ansTemp);
				printf("strTemp : %s", strTemp);

				printf("pAnswerLine : %s", pAnswerLine);
				printf("pStdLine : %s", pStdLine);

				// 비교하다가 끝나면
				if(pAnswerLine==NULL && pStdLine==NULL){
					printf("\n\nfinally same.\n\n");
					int r;
					int index_numlist=0;
					for(r=0;r<listcount-2;r++){
						if(!strcmp(answerQ[r],proNum[i])){
							index_numlist=r;
							printf("%d\n",index_numlist);
							break;
						}
					}					
						int stud_Id=atoi(studentId[j])-20190001;
						finalScore[stud_Id][index_numlist]=num[r].score;
					
						printf("stu : %d, ques : %d, num[i].score:%lf \n", stud_Id, index_numlist, num[index_numlist].score);	
					
					break;
				
				}

				else if (pAnswerLine ==NULL || pStdLine == NULL){
					printf("\n\nnot same\n\n");
					break;
				}

				if (!strcasecmp(pAnswerLine, pStdLine)) {
					printf("\n\nsame.\n\n");
					continue;
				}
				else{
					printf("\n\nnot same\n\n");
					break;
				}

//				printf("finallllll\n");
		
		
		
		}

		//	 fclose함수는 종료시 오류가 발생하면
		//	   0이 아닌 다른값을 리턴하므로 비정상 종료로 판단되면
		//	   안내후 프로그램을 종료
		state1 = fclose(noSpaceAnsFile);
		state2 = fclose(noSpaceStdFile);
		if (state1 != 0 || state2 != 0) {
			printf("stream close error\n");
			
		}
	}

//	remove(no_path_a);


}

//------------sum


for(i=0;i<num_s;i++){
   for(j=0;j<listcount-2;j++){
      sum[i]+=finalScore[i][j];
   }
}

makeFinal_Score_table(studentId, num, ans_folder, num_s, listcount-2) ;


//e 옵션이 아닐 때 만든 에러파일들 삭제

//printf("e 옵션이 아닐 때 만든 에러파일들을 삭제할 거예요!\n");
if(!e_flag){

//	printf("e 옵션이 아니군요!\n");
//	printf("e 옵션이 아니니, 에러 파일을 지웁시다!\n");
	for(i=0;i<problemC;i++){
		char deleteAns[MAX_SIZE];
		sprintf(deleteAns,"%s/%s/%s/%s_err.txt",path,ans_folder,proNum[i],proNum[i]);

//		printf("deleteAns : %s\n", deleteAns);

		for(j=0;j<num_s;j++){
			char deleteStd[MAX_SIZE];
			sprintf(deleteStd,"%s/%s/%s/%s_err.txt",path,std_folder,studentId[j],proNum[i]);
			printf("deleteStd : %s\n", deleteStd);
			remove(deleteStd);
//			printf("%s 파일을 지우는 데 성공하였습니다!\n", deleteStd);
		}
		remove(deleteAns);
//		printf("%s 파일을 지우는 데 성공하였습니다!\n", deleteAns);
	}
//	printf("err 모든 파일을 지우는 데 성공했습니다!\n");	
}
else {
	// 정답 에러 파일만 지움
	char deleteAns[MAX_SIZE];
	sprintf(deleteAns,"%s/%s/%s/%s_err.txt",path,ans_folder,proNum[i],proNum[i]);
	remove(deleteAns);

	// 에러파일을 돌면서 에러파일이 비어 있으면 삭제
	for(j=0;j<num_s;j++){
		int allnoerror = 0;
		for(i=0;i<problemC;i++){
			char deleteStd[MAX_SIZE];
			int fd_error_txt;
			int fd_error_size;
			sprintf(deleteStd,"%s/%s/%s/%s_err.txt",path,eName,studentId[j],proNum[i]);
			printf("에러 파일의 경로 : %s\n", deleteStd);
			fd_error_txt=open(deleteStd,O_RDWR,0777);
			fd_error_size=lseek(fd_error_txt,0,SEEK_END);
			printf("에러 파일의 크기는 : %d\n", fd_error_size);
			close(fd_error_txt);
			if (fd_error_size == 0) {
				allnoerror++;
				remove(deleteStd);
			}
		}
		if(allnoerror == problemC) {
			char deleteStdFile[MAX_SIZE];
			sprintf(deleteStdFile, "%s/%s/%s",path,eName,studentId[j]);
			rmdir(deleteStdFile);
		}
	}
}

//------------no_spa파일들 삭제

//printf("no_spa파일들을 삭제할 거예요!\n");
	for(i=0;i<problemC;i++){
		char delete_no_spa_Ans[MAX_SIZE];
		sprintf(delete_no_spa_Ans,"%s/%s/%s/no_spa_%s.txt",path,ans_folder,proNum[i],proNum[i]);

		printf("delete_no_spa_Ans : %s\n", delete_no_spa_Ans);

		for(j=0;j<num_s;j++){
			char delete_no_spa_Std[MAX_SIZE];
			sprintf(delete_no_spa_Std,"%s/%s/%s/no_spa_%s.txt",path,std_folder,studentId[j],proNum[i]);
			printf("delete_no_spa_Std : %s\n", delete_no_spa_Std);
			remove(delete_no_spa_Std);
//			printf("%s 파일을 지우는 데 성공하였습니다!\n", delete_no_spa_Std);
		}
		remove(delete_no_spa_Ans);
//		printf("%s 파일을 지우는 데 성공하였습니다!\n", delete_no_spa_Ans);
	}
//	printf("no_spa 모든 파일을 지우는 데 성공했습니다!\n");	


	//평균만 출력
	double average=0;
	int u_count;
	if(p_flag) {
	      //studentId에 학번이 저장되어 있음. 개수는 num_s
	      for(u_count=0;u_count<num_s;u_count++){
		 printf("%s is finished.. score : %.1lf\n",studentId[u_count],sum[u_count]);
		 average+=sum[u_count];
	      }
	      printf("Total average : %.2lf\n",average/num_s);
	   }
	   else{
	      for(u_count=0;u_count<num_s;u_count++){
		 printf("%s is finished..\n",studentId[u_count]);
	      }

	}

/*
	//-----------------------------------------------result grading!!!

	//warning error count!!
	//for loop of student folder
	//scan -> stdout
	//compare "warning" / "error"
	// discount!!

	//------------------------------------------------------------------------------
*/

	//확인
	printf("옵션인자 확인 - p_flag : %d, c_flag : %d\n", p_flag, c_flag);

	//옵션함수들 실행
	if (c_flag) {
		optionC(optCount1);//...??
	}
	closedir(dir);
	closedir(dir2);

//-----------
free(num);



	printf("THE END\n");
	gettimeofday(&end_t, NULL);
	ssu_runtime(&begin_t, &end_t);
	exit(0);
}

//-----------------main end----------------------------------//

void makeScore_table(char* folder, struct ans_num* num, int listcount) {
	FILE *pFile;
	char pFilePath[MAX_SIZE];
	sprintf(pFilePath, "./%s/score_table.csv", folder);
	printf("%s\n", pFilePath);
	int selectScore;
	double b_score;
	double p_score;
	double eachScore;
	int i;

	if ((pFile = fopen(pFilePath, "r+")) == NULL) {
		printf("score_table.csv file doesn't exist in %s!\n", folder);
		pFile = fopen(pFilePath, "w+");
		printf("1. input blank question and program question's score. ex) 0.5 1\n");
		printf("2. input all question's score. ex) Input value of 1-1: 0.1\n");
		printf("select type >> ");
		scanf("%d", &selectScore);

		switch (selectScore) {
			case 1:
				printf("Input value of blank question : ");
				scanf("%lf", &b_score);
				printf("Input value of program question : ");
				scanf("%lf", &p_score);

				for (i = 0; i < listcount - 2; i++) {
					if (num[i].name_s != 0) {
						fprintf(pFile, "%s,%.2lf\n", num[i].file_name, b_score);
						num[i].score = b_score;
					}
					else {

						fprintf(pFile, "%s,%.2lf\n", num[i].file_name, p_score);
						num[i].score = p_score;
					}
				}
				break;
			case 2:
				for (i = 0; i < listcount - 2; i++) {
					printf("Input of %s: ", num[i].file_name);
					scanf("%lf", &eachScore);
					fprintf(pFile, "%s,%.2lf\n", num[i].file_name, eachScore);
					num[i].score = eachScore;
				}
				break;
			default:
				printf("wrong type!\n");
				exit(1);
		}

	}
	else {
		i = 0;
		char a[1024];
		char b[1024];
		while(fgets(a,sizeof(a),pFile)!=NULL){
			strcpy(b,strtok(a,","));
			printf("b:%s\n", b);
			strcpy(num[i].file_name, b);;
			strcpy(b,strtok(NULL,",a"));
			printf("b:%s\n", b);
			num[i].score=atof(b);
			printf("i:%d, num[i].file_name: %s, num[i].score = %lf\n", i, num[i].file_name, num[i].score);
			i++;
			if(strtok(NULL,",")=="\n")
				continue;
		}

	


	}
	fclose(pFile);
}

void makeFinal_Score_table(char** stdId, struct ans_num* num, char* folder, int stdCount, int ansCount) {
	int row, col;
	FILE *pFile;
	char pFilePath[MAX_SIZE];
	strcpy(pFilePath, "./score.csv");
	printf("final score's path : %s----\n", pFilePath);
	int i,j;
	
	pFile = fopen(pFilePath, "w+");
	printf("pfile을 읽었으며 경로는 ./score.csv입니다!\n");
	
	fprintf(pFile, " ,");

	for (i = 0; i < ansCount; i++) {
		fprintf(pFile, "%s,", num[i].file_name);
	}

	fprintf(pFile, "sum\n");

	//1st col
	for (i = 0; i < stdCount; i++) {
		fprintf(pFile, "%d,",atoi(stdId[i]));
		for (j = 0; j < ansCount; j++) {
			fprintf(pFile, "%.2lf,", finalScore[i][j]);
		}
		fprintf(pFile, "%.2lf\n", sum[i]);
	}

	//otherwise...
	fclose(pFile);
	printf("makeFinal_Score_table 완료!\n");
}

void EraseSpace(char *ap_string)
{
	// p_dest 포인터도 ap_string 포인터와 동일한 메모리를 가리킨다.
	char *p_dest = ap_string;
	// 문자열의 끝을 만날때까지 반복한다.
	while (*ap_string != 0) {

		// ap_string이 가리키는 값이 공백 문자가 아닌 경우만
		// p_dest가 가리키는 메모리에 값을 복사한다.
		if (*ap_string != ' ') {
			if (p_dest != ap_string) *p_dest = *ap_string;
			// 일반 문자를 복사하면 다음 복사할 위치로 이동한다.
			p_dest++;
		}
		// 다음 문자 위치로 이동한다.
		ap_string++;
	}
	// 문자열의 끝에 NULL 문자를 저장한다.
	*p_dest = 0;
}

int list_dir(const char* path,char** saveName){
	struct dirent *entry;
	DIR *dir = opendir(path);
	int count=0;
	if(dir==NULL){
		return count;
	}
	while((entry = readdir(dir))!=NULL){
		if ((!strcmp(entry->d_name, ".")) || (!strcmp(entry->d_name, "..")))
			continue;

		saveName[count]=entry->d_name;
		count++;
	}	
	closedir(dir);
	return count;
}

void gradingC( char*problemC, char*path) {
	FILE  *noSpaceAnsFile;
	FILE *answerFile;

	//문제 번호 붙여서 루트 설정
	char no_path_a[MAX_SIZE];
	char path_a[MAX_SIZE];
	sprintf(path_a,"%s/%s.stdout",path,problemC);
	sprintf(no_path_a, "%s/no_spa_%s.txt", path,problemC);

	printf("공백 제거전 정답의 경로 : %s\n",path_a);
	printf("공백 제거한 정답의 경로 : %s\n",no_path_a);
 
	noSpaceAnsFile = fopen(no_path_a, "w+");
	answerFile = fopen(path_a, "r+"); //파일 위치

	if (answerFile != NULL)
	{
		char strTemp[MAX_SIZE];
		char* pStr=NULL;
		char* pStr_backup=NULL;//백업용!

		do{
			pStr = fgets(strTemp, sizeof(strTemp), answerFile);
			if(feof(answerFile)) break;
			pStr_backup=pStr;
			EraseSpace(pStr);
			//pStr을 새로운 텍스트에 저장!
			fprintf(noSpaceAnsFile,"%s", pStr);
			printf("공백을 제거한 정답은 : %s\n",pStr);
		}
		while (!feof(answerFile));
			fclose(noSpaceAnsFile);
		
		fclose(answerFile);
	}
	else
	{
		//에러 처리
	}

	printf("gradingC End!\n");
}
void programCompile(char* path,char* problemNum, int anscheck ,char*stdId){
	//anscheck==0 정답, anscheck==1 학생
	char* gccname="gcc -o";
	char name[PATH_MAX];
	int i;
	pthread_t threadID;

	// threadID로 TID를 받아오고, threadRoutine라는 함수 포인터로 스레드를 실행한다.
	char checkname[PATH_MAX];
	sprintf(checkname,"%s/%s.exe",path,problemNum);
	
	sprintf(name,"%s %s %s/%s.c",gccname,checkname,path,problemNum);
	//gcc -o .exe .c
	
	int check;
	int fd1,fd2,bk,bk2;
	bk=open("dummy",O_WRONLY|O_CREAT);
	bk2=open("dummy2",O_WRONLY|O_CREAT);
	close(bk);
	close(bk2);
	dup2(1,bk);
	dup2(2,bk2);
	char res[PATH_MAX];
	char errRedirection[PATH_MAX];

	sprintf(res,"%s/%s.stdout",path,problemNum);
	
	if((fd2=open(res,O_WRONLY|O_CREAT|O_TRUNC))==-1){
		fprintf(stderr, "open error for %s\n",res);
		exit(1);
	}
	fchmod(fd2,0777);
	dup2(fd2,1);

	if(e_flag&&anscheck){
		char e_errRedirection[MAX_SIZE];
		char now_path[MAX_SIZE];
		getcwd(now_path,200);
		sprintf(e_errRedirection,"%s/%s/%s/%s_err.txt",now_path,eName,stdId,problemNum);
		if((fd1=open(e_errRedirection,O_WRONLY|O_CREAT|O_TRUNC))==-1){
			fprintf(stderr, "open error for %s\n",e_errRedirection);
			exit(1);
		}
		fchmod(fd1,0777);
		dup2(fd1,2);
	}
	else{
		sprintf(errRedirection,"%s/%s_err.txt",path,problemNum);
		if((fd1=open(errRedirection,O_WRONLY|O_CREAT|O_TRUNC))==-1){
			fprintf(stderr, "open error for %s\n",errRedirection);
			exit(1);
		}
		fchmod(fd1,0777);
		dup2(fd1,2);
	}



	system(name);
	//gcc -o ~~~

	char argument[MAX_SIZE];
	sprintf(argument, "%s", checkname);
	int ch=0;
	char e_errRedirection[MAX_SIZE];

	//t option
	if((check=access(checkname,F_OK))<0){
		if(t_flag){
			int h;
			dup2(bk,1);
			dup2(bk2,2);

			close(fd2);
			close(fd1);
			//remove(res);

			if((fd2=open(res,O_WRONLY|O_CREAT|O_TRUNC))==-1){
				fprintf(stderr, "open error for %s\n",res);
				exit(1);
			}
			fchmod(fd2,0777);
			dup2(fd2,1);
			if(e_flag&&anscheck){
				char now_path[MAX_SIZE];
				getcwd(now_path,200);
				sprintf(e_errRedirection,"%s/%s/%s/%s_err.txt",now_path,eName,stdId,problemNum);
				if((fd1=open(e_errRedirection,O_WRONLY|O_CREAT|O_TRUNC))==-1){
					fprintf(stderr, "open error for %s\n",e_errRedirection);
					exit(1);
				}
				fchmod(fd1,0777);
				dup2(fd1,2);
			}
			else{
				sprintf(errRedirection,"%s/%s_err.txt",path,problemNum);
				if((fd1=open(errRedirection,O_WRONLY|O_CREAT|O_TRUNC))==-1){
					fprintf(stderr, "open error for %s\n",errRedirection);
					exit(1);
				}
				fchmod(fd1,0777);
				dup2(fd1,2);
			}


			for(h=0;h<optCount2;h++){
				if(!strcmp(tName[h],problemNum)){
					char new_system_name[MAX_SIZE];
					sprintf(new_system_name,"%s -lpthread",name);
					system(new_system_name);
				}
			}
		}
		//t는 구현끝
		else{
			ch=1;
			dup2(bk,1);
			dup2(bk2,2);
			remove("dummy");
			remove("dummy2");
			close(fd2);
			close(fd1);
			//remove(res);

		}
	}

	if(ch==0){
		pthread_create(&threadID, NULL, threadRoutine, (void*)argument);
		pthread_detach(threadID);


		if (!check_thread_status(argument, TIME_LIMIT)) {
			pthread_cancel(threadID);
		}
		
		dup2(bk,1);
		dup2(bk2,2);
		remove("dummy");
		remove("dummy2");
		close(fd2);
		close(fd1);
	}
	// ~~~.stdout making..
	if(e_flag){
		off_t filesize;
		filesize = lseek(fd1,0,SEEK_END);
		if(filesize==0){

			remove(e_errRedirection);
		}
	}

}

void *threadRoutine(void *argumentPointer)
{
	char *argument = (char *)argumentPointer;

	system(argument);

	strcpy(argument, "end");

	// 부모 스레드 부분에서 리턴값을 받기때문에 항상 리턴을 해준다.
	return NULL;
}

static int check_thread_status(char *pnWorkStatus, int nWaitTime){
	int i;
	// 주어진 nWaitTime 만큼만 대기
	for (i = 0; i < nWaitTime; i++){

		// 스레드가 완료된 시점에서는 *pnWorkStatus는 1이 된다.
		if (!strcmp(pnWorkStatus, "end"))
			return 1;
		sleep(1);
	}
	return 0;
}

void optionE(char* eName) {
	char err[MAX_SIZE];
	sprintf(err, "./%s", eName);
	DIR *err_directory = NULL;
	int res;

	//e옵션 다음에 오는 인자명의 폴더가 있는지 확인. 없으면 새로 생성
	res = access(err, 0);
	if (res == -1) {
		mkdir(err, 0777);
	}

	//eName/학번/문제번호_error.txt에 에러메시지 출력


}

void optionP() {

}

void optionH() {
	printf("Usage : ssu_score <STUDENTDIR> <TRUEDIR> [OPTION]\n");
	printf("Option : \n");
	printf(" -e <DIRNAME>	print error on 'DIRNAME/ID/qname_error.txt' file\n");
	printf(" -t <QNAMES>	compile QNAME.C with -lpthread option\n");
	printf(" -h		print usage\n");
	printf(" -p		print student's score and total average\n");
	printf(" -c <IDS> 	print ID's score\n");
}


void optionC(int count) {

	struct dirent *dentry;
	struct stat fstat;
	DIR *dirp;
	int i;
	int check;
	char path[MAX_SIZE];
	// 현재 디렉토리를 연다.
	if ((dirp = opendir(".")) == NULL) {
		printf("error: opendir..\n");
		exit(1);
	}
	// 열린 디렉토리의 모든 항목을 읽는다.
	while (dentry = readdir(dirp)) {
		// 디렉토리의 항목의 아이노드번호가 0 아닌 것을 찾는다.
		// 아이노드번호가 0 이면 그 항은 삭제가 된 것이다.
		if (dentry->d_ino != 0) {

			// 읽어혼 항목중 "."(현재디렉토리)와 ".."(부모디렉토리)는 건너뛴다.
			// 이는 하위 디렉토리를 탐색하는 것이기 때문에 제외하는 것이다.
			if ((!strcmp(dentry->d_name, ".")) || (!strcmp(dentry->d_name, "..")))
				continue;

			// 현재 항목의 상태정보를 가져온다.
			stat(dentry->d_name, &fstat);

			// 현재 항목의 상태가 디렉토리일 경우 해당 디렉토리로 이동
			if (S_ISDIR(fstat.st_mode)) {
				chdir(dentry->d_name);
			}
			else if(S_ISREG(fstat.st_mode)){
				if (!strcmp(dentry->d_name, "score.csv")) {
					strcpy(path, dentry->d_name);
					check = 1;
					break;
					// 현재 항목의 상태가 일반파일인 경우
					// score.csv 찾기. 찾으면 while문 탈출
				}

			}
		}
	}
	// 열린 현재 디렉토리의 사용이 끝났으므로 닫아준다.
	closedir(dirp);

	FILE *pFile;
	char str_tmp[MAX_SIZE];
	int cnt ;
	int total = 0;
	int token_count=0;
	char *total_sum[100];
	char* p;
	char *b[MAX_SIZE];
	if ((pFile = fopen(path, "r+")) != NULL) {

		fgets(str_tmp, MAX_SIZE, pFile);
		cnt = 0;
		p = strtok(str_tmp, ",");
		while (p != NULL) {
			sprintf(b[cnt], "%s", p);
			cnt++;
			p = strtok(NULL, ",");
		}

		while (!feof(pFile)) {
			fgets(str_tmp, MAX_SIZE, pFile);
			p = strtok(str_tmp, ",");
			while(p!=NULL){
				for (i = 0; i < cnt; i++) {
					p = strtok(NULL, ",");
				}
				sprintf(total_sum[total], "%s", p);
				token_count++;
			}

		}
		for (i = 0; i < count; i++) {
			printf("%s's score : %s", cName[i], total_sum[atoi(cName[i]) - 20190000]);
		}

		if(check==0){
			printf("file is not exist!\n");
		}


		fclose(pFile);
	}
}

void subdirOutput(char*wd_a, char*answerQ, char*wd, char*studentId) {

	innerFileCount = 0;


	struct dirent*dentry;
	DIR*dirp;
	if (chdir(wd_a) < 0 || chdir(wd) < 0) {
		printf("error:chdir../n");
		exit(1);
	}

	if ((dirp = opendir(".")) == NULL) {
		printf("error:opendir..\n");
		exit(1);
	}

	while (dentry = readdir(dirp)) {
		if (innerFileCount >= 100) {
			printf("cannotsave\n");
		}
		if ((!strcmp(dentry->d_name, ".")) || (!strcmp(dentry->d_name, "..")))
			continue;
		studentFile[innerFileCount] = dentry->d_name;
		innerFileCount++;

	}



	/*
	   int j;
	   for (j = 0; j < innerFileCount; j++) {
	   printf("%s\n", studentFile[j]);
	   }
	   */



	closedir(dirp);

}
void ans_numSort(struct ans_num* num, int cnt) {
	//sort
	int i, j;
	struct ans_num num2;
	for (i = 0; i < cnt; i++) {
		for (j = 0; j < i; j++) {
			if (num[i].name_i < num[j].name_i) {
				num2 = num[i];
				num[i] = num[j];
				num[j] = num2;

			}
			if (num[i].name_i == num[j].name_i) {
				if (num[i].name_s < num[j].name_s) {
					num2 = num[i];
					num[i] = num[j];
					num[j] = num2;

				}
			}
		}
	}

}

