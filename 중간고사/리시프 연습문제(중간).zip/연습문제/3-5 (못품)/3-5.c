#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <dirent.h>
#include <string.h>
#include <sys/stat.h>

void search_directory(char *dir) {
	struct dirent *dentry;
	struct stat statbuf;
	DIR *dirp;
	char cwd[1024];

	getcwd(cwd, 1024);

	if (lstat(dir, &statbuf) < 0) {
		fprintf(stderr, "lstat error\n");
		exit(1);
	}

	// 안쪽까지 파고들어가야 함. 더 파고들어갈 수 없는 경우
	// 밑에꺼 실행
	
//	stat("ssu_test1/ssu_test1.txt", &statbuf);

	if (S_ISDIR(statbuf.st_mode)) {
		printf("this");
	}

	if (!S_ISDIR(statbuf.st_mode)) {
		printf("%s/%s\n", cwd, dentry->d_name);
		return;
	}

	if ((dirp = opendir(dir)) == NULL) {
		fprintf(stderr, "opendir error for %s\n", dir);
		exit(1);
	}

	chdir(dir);

	// 맨 처음 디렉토리
	chdir(cwd);


}

int main(int argc, char *argv[])
{
	if (argc < 2) {
		fprintf(stderr, "Usage : %s filename\n", argv[0]);
		exit(1);
	}
	search_directory(argv[1]);
}
